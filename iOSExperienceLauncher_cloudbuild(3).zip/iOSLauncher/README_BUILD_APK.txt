iOS Experience Launcher - automated APK build

This project includes a GitHub Actions workflow that builds a debug APK in the cloud.

After uploading this project to a GitHub repository:
1. Open the repository's Actions tab.
2. Select "Build Android APK".
3. Press "Run workflow" (or push to main/master to trigger automatically).
4. Open the completed workflow run.
5. In Artifacts, download "iOS-Experience-Launcher-APK".
6. Extract the ZIP artifact to get app-debug.apk and install it on your Android phone.

Note: The app is an Android launcher and can be selected as the Home app in Android.
A regular app cannot replace Android system Settings completely; its own iOS-style screens
can be used for launcher features, while system controls may open Android settings.
