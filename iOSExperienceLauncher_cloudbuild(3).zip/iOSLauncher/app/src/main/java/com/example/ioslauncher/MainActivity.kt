package com.example.ioslauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(244, 245, 249)
    private val blue = Color.rgb(0, 122, 255)
    private lateinit var root: LinearLayout
    private var page = "home"
    private val settingsItems = listOf("Wi-Fi", "Bluetooth", "Mobile Service", "Notifications", "Focus", "Screen Time", "Display & Brightness", "Sounds & Haptics", "Wallpaper", "Battery", "Privacy & Security", "General")
    private val appItems = listOf("Phone", "Messages", "Camera", "Photos", "Clock", "Settings", "Calendar", "Maps", "Music", "Weather", "Notes", "Files")
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }

    private fun base(title: String? = null) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18, 20, 18, 14) }
        setContentView(root)
        if (title != null) {
            val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
            val back = text("‹", 34, Color.BLACK).apply { setPadding(4,0,18,0); setOnClickListener { showHome() } }
            top.addView(back); top.addView(text(title, 26, Color.BLACK, true)); root.addView(top)
        }
    }
    private fun text(s: String, size: Int, color: Int, bold: Boolean = false): TextView = TextView(this).apply { text=s; textSize=size.toFloat(); setTextColor(color); if(bold) setTypeface(null, Typeface.BOLD) }
    private fun card(view: View, radius: Int = 18): View { view.background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius=radius.toFloat() }; return view }
    private fun showHome() {
        page="home"; base()
        val clock = text("2:41\nFriday, November 27", 30, Color.WHITE, true).apply { gravity=Gravity.CENTER; setPadding(0,40,0,30) }
        root.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xffa9c8ff.toInt(),0xfff0c5e4.toInt(),0xffe8d6bb.toInt())).apply { cornerRadius=0f }
        root.addView(clock)
        val grid = GridLayout(this).apply { columnCount=4; rowCount=3 }
        val names = listOf("Calendar","Photos","Camera","Weather","Clock","Maps","Notes","Files","Music","Phone","Messages","Settings")
        val emojis = listOf("📅","🌄","📷","🌤️","⏰","🗺️","📝","📁","🎵","📞","💬","⚙️")
        names.forEachIndexed { i,n ->
            val cell=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(4,12,4,12) }
            val icon=TextView(this).apply { text=emojis[i]; textSize=30f; gravity=Gravity.CENTER; background=GradientDrawable().apply { setColor(0xfffdfdfd.toInt()); cornerRadius=22f }; setPadding(12,10,12,10) }
            cell.addView(icon, LinearLayout.LayoutParams(70,70)); cell.addView(text(n,12,Color.WHITE).apply { gravity=Gravity.CENTER; setPadding(0,5,0,0 }))
            cell.setOnClickListener { when(n){ "Settings"->showSettings(); "Phone","Messages","Camera","Photos","Maps","Music","Clock","Calendar","Weather","Notes","Files"->launchAppByName(n); else -> showAppDrawer() } }
            val p=GridLayout.LayoutParams(); p.width=0; p.columnSpec=GridLayout.spec(i%4,1f); grid.addView(cell,p)
        }
        root.addView(grid)
        val spacer=Space(this); root.addView(spacer, LinearLayout.LayoutParams(1,0,1f))
        val dock=LinearLayout(this).apply { gravity=Gravity.CENTER; setPadding(10,8,10,8); background=GradientDrawable().apply { setColor(0x66ffffff); cornerRadius=32f } }
        listOf("📞","🌐","💬","🎵").forEach { e-> dock.addView(text(e,28,Color.BLACK).apply { gravity=Gravity.CENTER; setPadding(12,8,12,8) }) }
        root.addView(dock)
        val shortcuts=LinearLayout(this).apply { gravity=Gravity.CENTER; setPadding(0,8,0,0) }
        val cc=text("Control Center",13,Color.WHITE).apply { setPadding(12,8,12,8); background=GradientDrawable().apply { setColor(0x55ffffff); cornerRadius=20f }; setOnClickListener { showControlCenter() } }
        val drawer=text("App Library",13,Color.WHITE).apply { setPadding(12,8,12,8); setOnClickListener { showAppDrawer() } }
        shortcuts.addView(cc); shortcuts.addView(drawer); root.addView(shortcuts)
    }
    private fun showSettings() {
        page="settings"; base("Settings")
        val scroll=ScrollView(this); val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val account=card(LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,16,16,16); addView(text("👤   Apple Account",19,Color.BLACK,true)); addView(text("Sign in, iCloud, media & purchases",14,0xff777777.toInt())) })
        list.addView(account); addGap(list,12)
        settingsItems.forEach { item ->
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(12,13,12,13) }
            val icon=TextView(this).apply { text=iconFor(item); textSize=20f; gravity=Gravity.CENTER; background=GradientDrawable().apply { setColor(colorFor(item)); cornerRadius=10f }; setTextColor(Color.WHITE); setPadding(4,4,4,4) }
            row.addView(icon,LinearLayout.LayoutParams(38,38)); row.addView(text(item,16,Color.BLACK).apply { setPadding(12,0,0,0) },LinearLayout.LayoutParams(0,-2,1f)); row.addView(text("›",24,0xff999999.toInt()))
            row.setOnClickListener { settingsDetail(item) }; list.addView(row)
        }
        scroll.addView(list); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
    }
    private fun settingsDetail(name:String) {
        base(name)
        val note=text("These controls are presented in the custom iOS-style interface. Android may require a system permission or its own settings screen to apply certain changes.",14,0xff666666.toInt()).apply { setPadding(4,16,4,18) }
        root.addView(note)
        when(name){
            "Wi-Fi" -> button("Open Wi-Fi settings") { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
            "Bluetooth" -> button("Bluetooth settings") { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
            "Notifications" -> button("Notification settings") { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,packageName)) }
            "Display & Brightness" -> button("Display settings") { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
            "Sounds & Haptics" -> button("Sound settings") { startActivity(Intent(Settings.ACTION_SOUND_SETTINGS)) }
            "Battery" -> button("Battery settings") { startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) }
            "Privacy & Security" -> button("App permissions") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
            "General" -> button("Android system settings") { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            "Wallpaper" -> button("Choose wallpaper") { chooseWallpaper() }
            else -> button("Open related Android settings") { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
    }
    private fun button(label:String,action:()->Unit){ val b=Button(this).apply { text=label; setOnClickListener { action() } }; root.addView(card(b)) }
    private fun chooseWallpaper(){ val i=Intent(Intent.ACTION_PICK).apply { type="image/*" }; startActivityForResult(i,22) }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==22&&resultCode==RESULT_OK&&data?.data!=null) try { WallpaperManager.getInstance(this).setStream(contentResolver.openInputStream(data.data!!)) ; Toast.makeText(this,"Wallpaper applied",Toast.LENGTH_SHORT).show() }catch(e:Exception){Toast.makeText(this,"Could not apply wallpaper",Toast.LENGTH_SHORT).show()} }
    private fun showControlCenter(){ page="control"; base("Control Center"); val items=listOf("Wi-Fi","Bluetooth","Airplane mode","Flashlight","Screen recording","Brightness","Volume")
        val grid=GridLayout(this).apply{columnCount=2}; items.forEach{ s-> val v=TextView(this).apply{ text="◉\n$s"; textSize=17f; gravity=Gravity.CENTER; setTextColor(Color.BLACK); setPadding(16,25,16,25) }; grid.addView(card(v),GridLayout.LayoutParams().apply{width=0;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(6,6,6,6)}); v.setOnClickListener { when(s){ "Wi-Fi"->startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)); "Bluetooth"->startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); "Airplane mode"->startActivity(Intent(Settings.ACTION_SETTINGS)); else->Toast.makeText(this,"Feature needs additional Android access",Toast.LENGTH_SHORT).show() } } }; root.addView(grid) }
    private fun showAppDrawer(){ page="apps"; base("App Library"); val search=EditText(this).apply{hint="Search apps"}; root.addView(search); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; appItems.forEach{ n-> val row=text("▣   $n    ›",18,Color.BLACK).apply{setPadding(12,15,12,15);setOnClickListener{launchAppByName(n)}};list.addView(row)}; val sc=ScrollView(this);sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f)); search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){list.removeAllViews(); appItems.filter{it.contains(s.toString(),true)}.forEach{n->list.addView(text("▣   $n",18,Color.BLACK).apply{setPadding(12,12,12,12);setOnClickListener{launchAppByName(n)}})}};override fun afterTextChanged(s:android.text.Editable?){} }) }
    private fun launchAppByName(n:String){ val intent=packageManager.getLaunchIntentForPackage(packageName); if(n=="Settings")showSettings() else { val main=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER); val matches=packageManager.queryIntentActivities(main,0); val match=matches.firstOrNull{it.loadLabel(packageManager).toString().equals(n,true)}; if(match!=null)try{startActivity(Intent().setComponent(match.activityInfo.let{ComponentName(it.packageName,it.name)}))}catch(_:Exception){} else Toast.makeText(this,"App not found: $n",Toast.LENGTH_SHORT).show() } }
    private fun iconFor(n:String)=when(n){"Wi-Fi"->"◉";"Bluetooth"->"ᛒ";"Mobile Service"->"▥";"Notifications"->"♧";"Focus"->"☾";"Screen Time"->"⌛";"Display & Brightness"->"☼";"Sounds & Haptics"->"♫";"Wallpaper"->"▧";"Battery"->"▰";"Privacy & Security"->"◈";else->"⚙"}
    private fun colorFor(n:String)=when(n){"Wi-Fi"->0xff1686ff.toInt();"Bluetooth"->0xff1686ff.toInt();"Notifications"->0xffff453a.toInt();"Display & Brightness"->0xff777777.toInt();"Wallpaper"->0xff32c759.toInt();"Battery"->0xff32c759.toInt();"Privacy & Security"->0xff777777.toInt();else->0xff888888.toInt()}
    private fun addGap(parent:LinearLayout,h:Int){parent.addView(Space(this),LinearLayout.LayoutParams(1,h))}
}
